import { Controller, Get, Render } from '@nestjs/common';

@Controller('movies')
export class MoviesController {
  @Get()
  @Render('movies')
  getMovies() {
    return {};
  }
}
