import { Controller, Get, Render } from '@nestjs/common';

@Controller()
export class DefaultController {

    @Get()
    @Render('home')
    home() {
    return {}
    }
}