import { Controller, Get } from '@nestjs/common';
import { join } from 'path';
import { promises as fs } from 'fs';

@Controller('api')
export class ApiController {

    @Get('movies')
    async movies() {
        try {
            const filepath = join(__dirname, '../../../three/data/imdb_movies.json');
            return await fs.readFile(filepath, 'utf-8');
        } catch (err) {
            console.error('Erreur :', err);
            return { error: 'Could not read file' };
        }
    }

    @Get('actors')
    async actors() {
        try {
            const filepath = join(__dirname, '../../../three/data/imdb_actors.json');
            return await fs.readFile(filepath, 'utf-8');
        } catch (err) {
            console.error('Erreur :', err);
            return { error: 'Could not read file' };
        }
    }

    @Get('genres')
    async genres() {
        try {
            const filepath = join(__dirname, '../../../three/data/imdb_genres.json');
            return await fs.readFile(filepath, 'utf-8');
        } catch (err) {
            console.error('Erreur :', err);
            return { error: 'Could not read file' };
        }
    }

    @Get('countries')
    async countries() {
        try {
            const filepath = join(__dirname, '../../../three/data/imdb_countries.json');
            return await fs.readFile(filepath, 'utf-8');
        } catch (err) {
            console.error('Erreur :', err);
            return { error: 'Could not read file' };
        }
    }

}

