import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { MoviesController } from './movies/movies.controller';
import { ApiController } from './api/api.controller';
import { ApiModule } from './api/api.module';
import { MoviesModule } from './movies/movies.module';

@Module({
  imports: [ApiModule, MoviesModule],
  controllers: [AppController, MoviesController, ApiController],
  providers: [AppService],
})
export class AppModule {}
